// @flow
export const RECEIVE_STUFF = 'RECEIVE_STUFF'

export const FIND_LOAN_SUBMIT = 'FIND_LOAN_SUBMIT'
export const FIND_LOAN_BACK = 'FIND_LOAN_BACK'

export const NEW_LOAN_CONT = 'NEW_LOAN_CONT'
